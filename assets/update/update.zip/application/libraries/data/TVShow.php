<?php
/**
 * 	This class handles all the data you can get from a TVShow
 *
 * 	@author Alvaro Octal | <a href="https://twitter.com/Alvaro_Octal">Twitter</a>
 * 	@version 0.1
 * 	@date 11/01/2015
 * 	@link https://github.com/Alvaroctal/TMDB-PHP-API
 * 	@copyright Licensed under BSD (http://www.opensource.org/licenses/bsd-license.php)
 */

class TVShow extends TMDBObject {

    /**
     * 	Get the TVShow's original name
     *
     * 	@return string
     */
    public function getOriginalName() {
        return $this->_data['original_name'];
    }
    public function getTitle() {
        return $this->_data['original_name'];
    }
    public function getdata() {
        return $this->_data;
    }
    public function getLanguage() {
        return $this->_data['original_language'];
    }
    public function getTagline() {
        return $this->_data['original_name'];
    }
    public function getimdb_id() {
        return $this->_data['external_ids']['imdb_id'];
    }
    public function getPopularity() {
        return $this->_data['popularity'];
    }
	public function getProduction() {
		$gnr='';
		foreach($this->_data['production_companies'] as $gn){
			$gnr .=$gn['name'].', ';
		}
		return $gnr;
	}	
	public function getStatus() {
		return $this->_data['status'];
	}	
	public function getOriginalCountry() {
		$gnr='';
		foreach($this->_data['origin_country'] as $gn){
			$gnr .=$gn.', ';
		}
		return $gnr;
	}	
    /**
     * 	Get the TVShow's number of seasons
     *
     * 	@return int
     */
    public function getNumSeasons() {
        return $this->_data['number_of_seasons'];
    }

    /**
     *  Get the TVShow's number of episodes
     *
     * 	@return int
     */
    public function getNumEpisodes() {
        return $this->_data['number_of_episodes'];
    }

    /**
     *  Get a TVShow's season
     *
     *  @param int $numSeason The season number
     * 	@return int
     */
    public function getSeasonob() {
        return $this->_data['seasons'];
    }
    public function getSeason($numSeason) {
		
        foreach($this->_data['seasons'] as $season){
            if ($season['season_number'] == $numSeason){
                $data = $season;
                break;
            }
        }
        return new Season($data);
    }

    /**
     *  Get the TvShow's seasons
     *
     * 	@return Season[]
     */
	public function getSeasonsar() {
        return $this->_data['seasons'];
    }
    public function getSeasons() {
        $seasons = array();

        foreach($this->_data['seasons'] as $data){
            $seasons[] = new Season($data, $this->getID());
        }

        return $seasons;
    }

    /**
     * 	Get the TVShow's Poster
     *
     * 	@return string
     */
    public function getPoster() {
        return $this->_data['poster_path'];
    }

    /**
     * 	Get the TVShow's Backdrop
     *
     * 	@return string
     */
    public function getBackdrop() {
        return $this->_data['backdrop_path'];
    }

    /**
     * 	Get the TVShow's Overview
     *
     * 	@return string
     */
    public function getOverview() {
        return $this->_data['overview'];
    }

    /**
     * 	Get the TVShow's vote average
     *
     * 	@return int
     */
    public function getVoteAverage() {
        return $this->_data['vote_average'];
    }

    /**
     * 	Get the TVShow's vote count
     *
     * 	@return int
     */
    public function getVoteCount() {
        return $this->_data['vote_count'];
    }

    /**
     * 	Get if the TVShow is in production
     *
     * 	@return boolean
     */
    public function getInProduction() {
        return $this->_data['in_production'];
    }

	/**
     * 	Get the TVShow Credits
     *
     * 	@return array
     */
    public function getCredits() {
        return $this->_data['credits'];
    }
	
	/**
     * 	Get the TVShow Cast
     *
     * 	@return person[]
     */
	public function getCastArray() {
		return $this->_data['credits']['cast'];
	} 
	public function getCrewDirector() {
		
		$gnr='';
		$group=array();
		foreach ( $this->_data['credits']['crew'] as $value ) {
			if($value['job']=='Director'){
				$group[$value['name']] = $value;
			}
		}
		foreach($group as $gn){
			$gnr .=$gn['name'].', ';
		}
		return $gnr;
	}
	public function getAirDate() {
        return $this->_data['air_date'];
    }
    public function getCast() {
         $cast = array();

        foreach( $this->_data['credits']['cast'] as $data ){
            $cast[] = new Person( $data );
        }

        return $cast;
    }
	
	/**
     * 	Get the TVShow Crew
     *
     * 	@return person[]
     */
	 
	public function getCrewe() {
		
		$gnr='';
		$group=array();
		foreach ( $this->_data['credits']['crew'] as $value ) {
			$group[$value['name']] = $value;
		}
		foreach($group as $gn){
			$gnr .=$gn['name'].', ';
		}
		return $gnr;
	}	
    public function getCrew() {
         $crew = array();

        foreach( $this->_data['credits']['crew'] as $data ){
            $crew[] = new Person( $data );
        }

        return $crew;
    }
	
	/**
     * 	Get the TVShow Genres
     *
     * 	@return genre[]
     */
    public function getGenre() {
        $gnr='';
		foreach($this->_data['genres'] as $gn){
			$gnr .=$gn['name'].', ';
		}
		return $gnr;
    }
    public function getGenres() {
         $genres = array();

        foreach( $this->_data['genres'] as $data ){
            $genres[] = new Genre( $data );
        }
		
        return $genres;
    }

	//------------------------------------------------------------------------------
    // Load
    //------------------------------------------------------------------------------

    /**
     *  Reload the content of this class.<br>
     *  Could be used to update or complete the information.
     *  
     *  @param TMDB $tmdb An instance of the API handler, necesary to make the API call.
     */
    public function reload($tmdb) {
         return $tmdb->getTVShow($this->getID());
    }

}
?>
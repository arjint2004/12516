<?php
/**
 * 	This class handles all the data you can get from a Genre
 *
 * 	@author Olivier Nolbert | <a href="http://www.octopoos.com">Octopoos</a>
 * 	@version 0.1
 * 	@date 01/06/2015
 * 	@link https://github.com/olivier-at-octopoos/TMDB-PHP-API
 * 	@copyright Licensed under BSD (http://www.opensource.org/licenses/bsd-license.php)
 */

class Genre extends TMDBObject {
}
?>